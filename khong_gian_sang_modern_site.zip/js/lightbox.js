
(function(){
  const overlay = document.createElement('div');
  overlay.className='lb-backdrop';
  overlay.innerHTML = '<div class="lb-content"><button class="lb-close" aria-label="Đóng">✕</button><button class="lb-prev" aria-label="Trước">‹</button><img alt=""><button class="lb-next" aria-label="Sau">›</button><div class="lb-title"></div></div>';
  document.body.appendChild(overlay);
  const imgEl = overlay.querySelector('img');
  const titleEl = overlay.querySelector('.lb-title');
  const btnClose = overlay.querySelector('.lb-close');
  const btnPrev = overlay.querySelector('.lb-prev');
  const btnNext = overlay.querySelector('.lb-next');
  let group=[], index=0;
  function render(){
    const a = group[index];
    imgEl.src = a.getAttribute('href');
    titleEl.textContent = a.getAttribute('data-title') || a.querySelector('.caption')?.textContent || '';
  }
  function open(items, i){ group = items; index = i; render(); overlay.classList.add('show'); document.body.style.overflow='hidden'; }
  function close(){ overlay.classList.remove('show'); document.body.style.overflow=''; imgEl.removeAttribute('src'); }
  function prev(){ index = (index-1+group.length)%group.length; render(); }
  function next(){ index = (index+1)%group.length; render(); }
  document.addEventListener('click', (e)=>{
    const a = e.target.closest('a[data-lightbox]');
    if(!a) return;
    e.preventDefault();
    const name = a.getAttribute('data-lightbox');
    const items = Array.from(document.querySelectorAll(`a[data-lightbox="${name}"]`));
    open(items, items.indexOf(a));
  });
  overlay.addEventListener('click',(e)=>{ if(e.target===overlay) close(); });
  btnClose.addEventListener('click', close);
  btnPrev.addEventListener('click', prev);
  btnNext.addEventListener('click', next);
  document.addEventListener('keydown',(e)=>{
    if(!overlay.classList.contains('show')) return;
    if(e.key==='Escape') close();
    if(e.key==='ArrowLeft') prev();
    if(e.key==='ArrowRight') next();
  });
})();
